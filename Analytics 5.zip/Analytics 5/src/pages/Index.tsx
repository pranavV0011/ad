import { DashboardLayout } from "@/components/DashboardLayout";
import { getAllClientsAggregated } from "@/data/clients";

const Index = () => {
  const allClients = getAllClientsAggregated();
  return <DashboardLayout client={allClients} />;
};

export default Index;
