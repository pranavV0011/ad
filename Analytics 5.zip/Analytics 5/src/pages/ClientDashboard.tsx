import { useParams, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { loadClientConfig } from "@/configs/clientLoader";

export default function ClientDashboard() {
  const { clientId } = useParams();
  const [client, setClient] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!clientId) return;

    loadClientConfig(clientId).then(data => {
      setClient(data);
      setLoading(false);
    });
  }, [clientId]);

  if (loading) return <div className="p-10">Loading...</div>;
  if (!client) return <Navigate to="/" replace />;

  return <DashboardLayout client={client} />;
}
