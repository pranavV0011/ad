export const DASHBOARD_SECTIONS = [
  "performanceTrends",
  "revenueOverview",
  "automationScore",
  "automationPenetration",
  "arAging",
  "claimsVolume",
  "periodComparison",
  "topDenials",
  "clientPerformance",
] as const;

export type DashboardSection = typeof DASHBOARD_SECTIONS[number];
