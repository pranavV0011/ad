import type { DashboardSection } from "./dashboardSections";

export const CLIENT_DASHBOARD_LAYOUTS = {
  southside: {
    topKpis: ["totalClaims", "gcr", "fpr" , "ncr", "ccr", "denialRate"],
    sections: [
      "performanceTrends",
      "revenueOverview",
      "automationScore",
      "arAging",
      "claimsVolume",
      "periodComparison",
      "automationPenetration"
    ] satisfies readonly DashboardSection[]
  },

  all_clients: {
    topKpis: ["totalClaims","totalPayments","gcr","ncr","denialRate"],
    sections: [
      "performanceTrends",
      "revenueOverview",
      "arAging",
      "claimsVolume",
      "periodComparison",
      "topDenials",
      "clientPerformance"
    ] satisfies readonly DashboardSection[]
  }
} as const;
