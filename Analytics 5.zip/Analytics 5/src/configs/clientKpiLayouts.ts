export const CLIENT_KPI_LAYOUTS = {
  
    default: [
        "totalClaims",
        "totalPayments",
        "gcr",
        "ncr",
        "denialRate",
        "fpr",
        "ccr",
        "totalOpenAR",
  ],

    pomerene: [
        "totalClaims",
        "gcr",
        "ncr",
        "ccr",
    ],

    southside: [
        "gcr",
        "ccr",
        "denialRate",
        "totalClaims"
    ]

} as const;

   