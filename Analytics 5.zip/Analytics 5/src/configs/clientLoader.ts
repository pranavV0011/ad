export async function loadClientConfig(clientId: string) {
  try {
    const module = await import(`./clients/${clientId}.json`);
    return module.default;
  } catch (err) {
    console.error("Client not found:", clientId);
    return null;
  }
}
