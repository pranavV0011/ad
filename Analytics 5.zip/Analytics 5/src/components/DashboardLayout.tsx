import { DashboardSidebar } from "@/components/DashboardSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { KpiCards } from "@/components/KpiCards";
import {
  PerformanceTrendsAndRevenueChart,
  AutomationPenetrationCard,
  AutomationAnalyticsGauge,
  ArAgingChart,
  ClaimsVolumeChart,
  PeriodComparisonChart,
  DenialReasonsChart,
  ClientPerformanceTable,
} from "@/components/DashboardCharts";
import { CLIENT_DASHBOARD_LAYOUTS } from "@/configs/clientDashboardLayouts";

interface DashboardLayoutProps {
  client: any;
}

export function DashboardLayout({ client }: DashboardLayoutProps) {
  const layout =
    CLIENT_DASHBOARD_LAYOUTS[client.clientId as keyof typeof CLIENT_DASHBOARD_LAYOUTS] ??
    CLIENT_DASHBOARD_LAYOUTS.all_clients;

  console.log("clientId:", client.clientId, "layout:", layout);

  return (
    <div className="flex h-screen overflow-hidden">
      <DashboardSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <DashboardHeader title="Dashboard" />

        <main className="flex-1 overflow-y-auto bg-background p-6">
          <div className="mx-auto flex max-w-[1600px] gap-5">

            {/* LEFT 70% */}
            <div className="flex flex-[7] flex-col gap-5 min-w-0">

              {layout.topKpis && <KpiCards kpis={client.kpis} />}

              {layout.sections.includes("performanceTrends") && (
                <PerformanceTrendsAndRevenueChart
                  performanceData={client.performanceData}
                  revenueData={client.revenueData}
                />
              )}

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                {layout.sections.includes("arAging") && <ArAgingChart data={client.arAging} />}
                {layout.sections.includes("claimsVolume") && <ClaimsVolumeChart data={client.claimsVolume} />}
                {layout.sections.includes("periodComparison") && <PeriodComparisonChart data={client.periodComparison} />}
              </div>

              {(layout.sections.includes("topDenials") ||
                layout.sections.includes("clientPerformance")) && (
                <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                  {layout.sections.includes("topDenials") && (
                    <DenialReasonsChart data={client.denialReasons} />
                  )}
                  {layout.sections.includes("clientPerformance") && (
                    <ClientPerformanceTable data={client.clientPerformance} />
                  )}
                </div>
              )}
            </div>

            {/* RIGHT 30% — MUST be a sibling */}
            {(layout.sections.includes("automationScore") ||
              layout.sections.includes("automationPenetration")) && (
              <div className="hidden flex-[3] flex-col gap-0 lg:flex">
                <div className="flex flex-col gap-5 sticky top-0">
                  {layout.sections.includes("automationScore") && (
                    <AutomationAnalyticsGauge items={client.automationItems} />
                  )}
                  {layout.sections.includes("automationPenetration") && (
                    <AutomationPenetrationCard items={client.automationItems} />
                  )}
                </div>
              </div>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}



