import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import {
  DollarSign,
  FileText,
  TrendingUp,
  TrendingDown,
  Activity,
  ShieldCheck,
  Zap,
  Wallet,
} from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import type { ClientKpi } from "@/data/clients";
import { CLIENT_KPI_LAYOUTS } from "@/configs/clientKpiLayouts";

interface KpiCardsProps {
  kpis: ClientKpi;
}

const kpiConfig = [
  { key: "totalClaims" as const, label: "Total Claims", icon: FileText, colorClass: "text-chart-blue", bgClass: "bg-chart-blue/10", ringClass: "ring-chart-blue/20" },
  { key: "totalPayments" as const, label: "Total Payments", icon: DollarSign, colorClass: "text-chart-green", bgClass: "bg-chart-green/10", ringClass: "ring-chart-green/20" },
  { key: "gcr" as const, label: "GCR", icon: TrendingUp, colorClass: "text-chart-purple", bgClass: "bg-chart-purple/10", ringClass: "ring-chart-purple/20" },
  { key: "ncr" as const, label: "NCR", icon: Activity, colorClass: "text-chart-amber", bgClass: "bg-chart-amber/10", ringClass: "ring-chart-amber/20" },
  { key: "denialRate" as const, label: "Denial Rate", icon: TrendingDown, colorClass: "text-chart-red", bgClass: "bg-chart-red/10", ringClass: "ring-chart-red/20" },
  { key: "fpr" as const, label: "FPR", icon: Zap, colorClass: "text-chart-blue", bgClass: "bg-chart-blue/10", ringClass: "ring-chart-blue/20" },
  { key: "ccr" as const, label: "CCR", icon: ShieldCheck, colorClass: "text-chart-green", bgClass: "bg-chart-green/10", ringClass: "ring-chart-green/20" },
  { key: "totalOpenAR" as const, label: "Total Open AR", icon: Wallet, colorClass: "text-chart-purple", bgClass: "bg-chart-purple/10", ringClass: "ring-chart-purple/20" },
];


const downKeys = new Set(["denialRate", "totalOpenAR"]);

export function KpiCards({ kpis }: KpiCardsProps) {
  const navigate = useNavigate();
  const { clientId } = useParams();

  const handleKpiClick = (key: string) => {
    const path = clientId ? `/client/${clientId}/kpi/${key}` : `/kpi/${key}`;
    navigate(path);
  };

  type KpiKey = (typeof kpiConfig)[number]["key"];


  const kpiKeys =
  (CLIENT_KPI_LAYOUTS[clientId as keyof typeof CLIENT_KPI_LAYOUTS] ??
    CLIENT_KPI_LAYOUTS.default) as readonly KpiKey[];


  const activeKpis = kpiConfig.filter(kpi =>
    kpiKeys.includes(kpi.key)
  )

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {activeKpis.map((cfg) => {
        const change = kpis.changes[cfg.key];
        const isDown = change.startsWith("-");
        const trendPositive = downKeys.has(cfg.key) ? isDown : !isDown;
        const Icon = cfg.icon;

        return (
          <Card
            key={cfg.key}
            className="card-elevated group relative overflow-hidden border-0 p-4 transition-all duration-200 hover:scale-[1.01] cursor-pointer"
            onClick={() => handleKpiClick(cfg.key)}
          >
            {/* Subtle top accent line */}
            <div className={cn("absolute inset-x-0 top-0 h-0.5 opacity-40", cfg.bgClass.replace('/10', ''))} />
            <div className="flex items-start gap-3.5">
              <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ring-1", cfg.bgClass, cfg.ringClass)}>
                <Icon className={cn("h-[18px] w-[18px]", cfg.colorClass)} />
              </div>
              <div className="flex flex-col gap-0.5 min-w-0">
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide">{cfg.label}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-bold text-card-foreground tracking-tight">{kpis[cfg.key]}</span>
                  <span className={cn(
                    "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[10px] font-bold",
                    trendPositive ? "text-success bg-success/10" : "text-destructive bg-destructive/10"
                  )}>
                    {trendPositive ? "↑" : "↓"} {change.replace("-", "").replace("+", "")}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
