import { cn } from "@/lib/utils";
import {
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Settings,
  HelpCircle,
  LayoutDashboard,
  Building2,
} from "lucide-react";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getClients } from "@/data/clients";

export function DashboardSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const { clientId } = useParams();
  const navigate = useNavigate();
  const clients = getClients();

  const activeId = clientId || "all";

  return (
    <aside
      className={cn(
        "flex h-screen flex-col bg-sidebar text-sidebar-foreground transition-all duration-300 relative",
        collapsed ? "w-[68px]" : "w-60"
      )}
    >
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none" />

      {/* Logo */}
      <div className="relative flex h-16 items-center gap-3 px-4 border-b border-sidebar-border">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-sidebar-primary to-accent shadow-lg shadow-sidebar-primary/20">
          <BarChart3 className="h-4.5 w-4.5 text-sidebar-primary-foreground" />
        </div>
        {!collapsed && (
          <div className="flex flex-col">
            <span className="text-sm font-bold leading-tight tracking-tight text-sidebar-foreground">Jorie AI</span>
            <span className="text-[10px] font-medium leading-tight text-sidebar-foreground/50">Analytics Suite</span>
          </div>
        )}
      </div>

      {/* Section label */}
      {!collapsed && (
        <div className="relative px-5 pt-5 pb-1">
          <span className="text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/30">Clients</span>
        </div>
      )}

      {/* Nav */}
      <nav className="relative flex flex-1 flex-col gap-0.5 overflow-y-auto px-3 pt-2 scrollbar-thin">
        <button
          onClick={() => navigate("/")}
          className={cn(
            "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all duration-200",
            activeId === "all"
              ? "bg-sidebar-primary/15 text-sidebar-primary shadow-sm shadow-sidebar-primary/10"
              : "text-sidebar-foreground/50 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
          )}
        >
          <LayoutDashboard className={cn("h-4 w-4 shrink-0 transition-colors", activeId === "all" ? "text-sidebar-primary" : "text-sidebar-foreground/40 group-hover:text-sidebar-foreground/70")} />
          {!collapsed && <span>All Clients</span>}
        </button>

        {clients.map((client) => (
          <button
            key={client.id}
            onClick={() => navigate(`/client/${client.id}`)}
            className={cn(
              "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all duration-200",
              activeId === client.id
                ? "bg-sidebar-primary/15 text-sidebar-primary shadow-sm shadow-sidebar-primary/10"
                : "text-sidebar-foreground/50 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
            )}
          >
            <div className={cn(
              "flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-[10px] font-bold transition-colors",
              activeId === client.id
                ? "bg-sidebar-primary/20 text-sidebar-primary"
                : "bg-sidebar-accent text-sidebar-foreground/40 group-hover:text-sidebar-foreground/60"
            )}>
              {client.shortName.charAt(0)}
            </div>
            {!collapsed && <span className="truncate">{client.shortName}</span>}
          </button>
        ))}
      </nav>

      {/* Bottom */}
      <div className="relative flex flex-col gap-0.5 border-t border-sidebar-border px-3 py-3">
        <button className="group flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium text-sidebar-foreground/40 transition-all duration-200 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground">
          <Settings className="h-4 w-4 shrink-0 transition-colors group-hover:text-sidebar-foreground/70" />
          {!collapsed && <span>Settings</span>}
        </button>
        <button className="group flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium text-sidebar-foreground/40 transition-all duration-200 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground">
          <HelpCircle className="h-4 w-4 shrink-0 transition-colors group-hover:text-sidebar-foreground/70" />
          {!collapsed && <span>Help</span>}
        </button>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="group flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium text-sidebar-foreground/30 transition-all duration-200 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground/60"
        >
          {collapsed ? (
            <ChevronRight className="h-4 w-4 shrink-0" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4 shrink-0" />
              <span>Collapse</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
}
