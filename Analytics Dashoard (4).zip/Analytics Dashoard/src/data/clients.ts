export interface ClientKpi {
  totalClaims: string;
  totalPayments: string;
  gcr: string;
  ncr: string;
  denialRate: string;
  fpr: string;
  ccr: string;
  totalOpenAR: string;
  changes: {
    totalClaims: string;
    totalPayments: string;
    gcr: string;
    ncr: string;
    denialRate: string;
    fpr: string;
    ccr: string;
    totalOpenAR: string;
  };
}

export interface PerformanceDataPoint {
  month: string;
  GCR: number;
  NCR: number;
  DR: number;
  CCR: number;
  FPR: number;
  TotalPayments: number;
}

export interface ClaimsVolumePoint {
  month: string;
  submitted: number;
  processed: number;
  denied: number;
}

export interface ArAgingPoint {
  bucket: string;
  amount: number;
}

export interface DenialReason {
  reason: string;
  count: number;
  percentage: number;
}

export interface RevenuePoint {
  month: string;
  payments: number;
  billed: number;
}

export interface PeriodComparison {
  metric: string;
  previous: number;
  current: number;
}

export interface AutomationItem {
  name: string;
  value: string;
}

export interface ClientPerformanceRow {
  client: string;
  gcr: string;
  totalPayments: string;
  dr: string;
  status: "Excellent" | "Good" | "Fair";
}

export interface ClientData {
  id: string;
  name: string;
  shortName: string;
  kpis: ClientKpi;
  performanceData: PerformanceDataPoint[];
  claimsVolume: ClaimsVolumePoint[];
  arAging: ArAgingPoint[];
  denialReasons: DenialReason[];
  revenueData: RevenuePoint[];
  periodComparison: PeriodComparison[];
  automationItems: AutomationItem[];
  clientPerformance: ClientPerformanceRow[];
}

const automationItemNames = [
  "Billing Accuracy Report", "FastTrack Appointments", "SDEC Eligibility and Auth",
  "WKI Eligibility", "WKI Encounters form", "WKI HubSpot",
  "WKI Injection charge scrub", "WKI Medical Charge Scrub", "WKI Non Par",
  "WKI Pre Authorization", "WKI No Show Appointment", "SDEC Encounters Form",
  "Drug Count", "Charges", "Payment Posting",
  "Account Receivable", "Eligibility Verification", "FTE",
];

const defaultAutomation: AutomationItem[] = automationItemNames.map((name) => ({
  name,
  value: "0.0%",
}));

const defaultPerformanceTable: ClientPerformanceRow[] = [
  { client: "Acme Healthcare", gcr: "96.1%", totalPayments: "91.2%", dr: "3.8%", status: "Excellent" },
  { client: "Metro Medical", gcr: "93.5%", totalPayments: "88.7%", dr: "5.1%", status: "Good" },
  { client: "Valley Clinic", gcr: "92.8%", totalPayments: "87.4%", dr: "5.9%", status: "Good" },
  { client: "Summit Health", gcr: "90.1%", totalPayments: "85.3%", dr: "7.2%", status: "Fair" },
  { client: "Riverside Care", gcr: "94.7%", totalPayments: "90.1%", dr: "4.5%", status: "Excellent" },
];

function makeRevenue(base: number): RevenuePoint[] {
  return [
    { month: "Jul", payments: base * 0.85, billed: base * 0.92 },
    { month: "Aug", payments: base * 0.88, billed: base * 0.94 },
    { month: "Sep", payments: base * 0.90, billed: base * 0.95 },
    { month: "Oct", payments: base * 0.92, billed: base * 0.96 },
    { month: "Nov", payments: base * 0.94, billed: base * 0.97 },
    { month: "Dec", payments: base * 0.91, billed: base * 0.95 },
    { month: "Jan", payments: base * 0.96, billed: base * 0.98 },
    { month: "Feb", payments: base, billed: base * 1.02 },
  ];
}

function makePeriodComparison(gcr: number, tp: number, ccr: number, fpr: number, dr: number): PeriodComparison[] {
  return [
    { metric: "GCR", previous: gcr - 2.5, current: gcr },
    { metric: "Total Payments", previous: tp - 3, current: tp },
    { metric: "CCR", previous: ccr - 1.5, current: ccr },
    { metric: "FPR", previous: fpr - 2, current: fpr },
    { metric: "DR", previous: dr + 1.5, current: dr },
  ];
}

const clients: ClientData[] = [
  {
    id: "pomerene",
    name: "Pomerene",
    shortName: "Pomerene",
    kpis: {
      totalClaims: "4,231", totalPayments: "$1.1M", gcr: "95.8%", ncr: "91.2%",
      denialRate: "4.2%", fpr: "93.1%", ccr: "97.3%", totalOpenAR: "$312K",
      changes: { totalClaims: "+14.2%", totalPayments: "+9.8%", gcr: "+2.5%", ncr: "+2.1%", denialRate: "-1.5%", fpr: "+4.1%", ccr: "+1.0%", totalOpenAR: "-5.1%" },
    },
    performanceData: [
      { month: "Jul", GCR: 90.1, NCR: 84.5, DR: 7.2, CCR: 92.8, FPR: 87.4, TotalPayments: 850000 },
      { month: "Aug", GCR: 91.3, NCR: 86.0, DR: 6.5, CCR: 93.5, FPR: 89.0, TotalPayments: 880000 },
      { month: "Sep", GCR: 92.7, NCR: 87.2, DR: 5.9, CCR: 94.2, FPR: 90.3, TotalPayments: 920000 },
      { month: "Oct", GCR: 93.0, NCR: 88.1, DR: 5.5, CCR: 95.0, FPR: 91.0, TotalPayments: 950000 },
      { month: "Nov", GCR: 94.5, NCR: 89.5, DR: 4.8, CCR: 96.1, FPR: 92.2, TotalPayments: 980000 },
      { month: "Dec", GCR: 95.0, NCR: 90.2, DR: 4.5, CCR: 96.8, FPR: 92.7, TotalPayments: 1020000 },
      { month: "Jan", GCR: 95.5, NCR: 90.8, DR: 4.3, CCR: 97.0, FPR: 93.0, TotalPayments: 1060000 },
      { month: "Feb", GCR: 95.8, NCR: 91.2, DR: 4.2, CCR: 97.3, FPR: 93.1, TotalPayments: 1100000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 480, processed: 460, denied: 35 },
      { month: "Aug", submitted: 520, processed: 500, denied: 34 },
      { month: "Sep", submitted: 550, processed: 530, denied: 32 },
      { month: "Oct", submitted: 580, processed: 560, denied: 30 },
      { month: "Nov", submitted: 610, processed: 590, denied: 28 },
      { month: "Dec", submitted: 570, processed: 550, denied: 25 },
      { month: "Jan", submitted: 630, processed: 610, denied: 27 },
      { month: "Feb", submitted: 660, processed: 640, denied: 28 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 95000 },
      { bucket: "31-60 days", amount: 72000 },
      { bucket: "61-90 days", amount: 58000 },
      { bucket: "90+ days", amount: 87000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 42, percentage: 28 },
      { reason: "Invalid Code", count: 35, percentage: 23 },
      { reason: "Missing Info", count: 30, percentage: 20 },
      { reason: "Timely Filing", count: 25, percentage: 17 },
      { reason: "Duplicate", count: 18, percentage: 12 },
    ],
    revenueData: makeRevenue(1100000),
    periodComparison: makePeriodComparison(95.8, 91.2, 97.3, 93.1, 4.2),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "drlo",
    name: "Dr Lo",
    shortName: "Dr Lo",
    kpis: {
      totalClaims: "3,518", totalPayments: "$890K", gcr: "92.4%", ncr: "87.8%",
      denialRate: "6.1%", fpr: "89.5%", ccr: "95.0%", totalOpenAR: "$245K",
      changes: { totalClaims: "+10.1%", totalPayments: "+6.5%", gcr: "+1.8%", ncr: "+1.4%", denialRate: "-0.9%", fpr: "+2.8%", ccr: "+0.6%", totalOpenAR: "-3.5%" },
    },
    performanceData: [
      { month: "Jul", GCR: 87.0, NCR: 81.0, DR: 9.0, CCR: 90.5, FPR: 84.0, TotalPayments: 680000 },
      { month: "Aug", GCR: 88.2, NCR: 82.5, DR: 8.3, CCR: 91.2, FPR: 85.5, TotalPayments: 720000 },
      { month: "Sep", GCR: 89.5, NCR: 84.0, DR: 7.8, CCR: 92.0, FPR: 87.0, TotalPayments: 760000 },
      { month: "Oct", GCR: 90.0, NCR: 85.2, DR: 7.2, CCR: 93.0, FPR: 87.8, TotalPayments: 790000 },
      { month: "Nov", GCR: 91.2, NCR: 86.5, DR: 6.8, CCR: 94.0, FPR: 88.5, TotalPayments: 820000 },
      { month: "Dec", GCR: 91.8, NCR: 87.0, DR: 6.5, CCR: 94.5, FPR: 89.0, TotalPayments: 850000 },
      { month: "Jan", GCR: 92.1, NCR: 87.5, DR: 6.3, CCR: 94.8, FPR: 89.3, TotalPayments: 870000 },
      { month: "Feb", GCR: 92.4, NCR: 87.8, DR: 6.1, CCR: 95.0, FPR: 89.5, TotalPayments: 890000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 400, processed: 375, denied: 38 },
      { month: "Aug", submitted: 430, processed: 405, denied: 36 },
      { month: "Sep", submitted: 450, processed: 425, denied: 35 },
      { month: "Oct", submitted: 470, processed: 445, denied: 33 },
      { month: "Nov", submitted: 490, processed: 468, denied: 30 },
      { month: "Dec", submitted: 460, processed: 438, denied: 28 },
      { month: "Jan", submitted: 510, processed: 485, denied: 32 },
      { month: "Feb", submitted: 530, processed: 508, denied: 33 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 78000 },
      { bucket: "31-60 days", amount: 62000 },
      { bucket: "61-90 days", amount: 48000 },
      { bucket: "90+ days", amount: 57000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 48, percentage: 30 },
      { reason: "Invalid Code", count: 38, percentage: 24 },
      { reason: "Missing Info", count: 32, percentage: 20 },
      { reason: "Timely Filing", count: 22, percentage: 14 },
      { reason: "Duplicate", count: 20, percentage: 12 },
    ],
    revenueData: makeRevenue(890000),
    periodComparison: makePeriodComparison(92.4, 87.8, 95.0, 89.5, 6.1),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "southside",
    name: "Southside",
    shortName: "Southside",
    kpis: {
      totalClaims: "2,890", totalPayments: "$720K", gcr: "93.5%", ncr: "88.9%",
      denialRate: "5.8%", fpr: "90.2%", ccr: "95.8%", totalOpenAR: "$198K",
      changes: { totalClaims: "+11.8%", totalPayments: "+7.9%", gcr: "+2.0%", ncr: "+1.6%", denialRate: "-1.1%", fpr: "+3.2%", ccr: "+0.7%", totalOpenAR: "-4.0%" },
    },
    performanceData: [
      { month: "Jul", GCR: 88.5, NCR: 82.8, DR: 8.5, CCR: 91.5, FPR: 85.8, TotalPayments: 560000 },
      { month: "Aug", GCR: 89.8, NCR: 84.2, DR: 7.8, CCR: 92.2, FPR: 86.9, TotalPayments: 600000 },
      { month: "Sep", GCR: 90.8, NCR: 85.5, DR: 7.2, CCR: 93.0, FPR: 87.8, TotalPayments: 640000 },
      { month: "Oct", GCR: 91.5, NCR: 86.5, DR: 6.8, CCR: 93.8, FPR: 88.5, TotalPayments: 660000 },
      { month: "Nov", GCR: 92.5, NCR: 87.5, DR: 6.2, CCR: 94.8, FPR: 89.5, TotalPayments: 690000 },
      { month: "Dec", GCR: 93.0, NCR: 88.2, DR: 6.0, CCR: 95.2, FPR: 89.8, TotalPayments: 700000 },
      { month: "Jan", GCR: 93.3, NCR: 88.6, DR: 5.9, CCR: 95.5, FPR: 90.0, TotalPayments: 710000 },
      { month: "Feb", GCR: 93.5, NCR: 88.9, DR: 5.8, CCR: 95.8, FPR: 90.2, TotalPayments: 720000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 320, processed: 305, denied: 28 },
      { month: "Aug", submitted: 350, processed: 335, denied: 27 },
      { month: "Sep", submitted: 370, processed: 355, denied: 26 },
      { month: "Oct", submitted: 385, processed: 370, denied: 25 },
      { month: "Nov", submitted: 400, processed: 385, denied: 24 },
      { month: "Dec", submitted: 375, processed: 360, denied: 22 },
      { month: "Jan", submitted: 420, processed: 405, denied: 25 },
      { month: "Feb", submitted: 440, processed: 425, denied: 26 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 62000 },
      { bucket: "31-60 days", amount: 48000 },
      { bucket: "61-90 days", amount: 38000 },
      { bucket: "90+ days", amount: 50000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 35, percentage: 27 },
      { reason: "Invalid Code", count: 32, percentage: 25 },
      { reason: "Missing Info", count: 28, percentage: 22 },
      { reason: "Timely Filing", count: 20, percentage: 15 },
      { reason: "Duplicate", count: 15, percentage: 11 },
    ],
    revenueData: makeRevenue(720000),
    periodComparison: makePeriodComparison(93.5, 88.9, 95.8, 90.2, 5.8),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "orthoone",
    name: "Ortho One",
    shortName: "Ortho One",
    kpis: {
      totalClaims: "2,208", totalPayments: "$580K", gcr: "94.5%", ncr: "90.1%",
      denialRate: "4.8%", fpr: "92.0%", ccr: "96.5%", totalOpenAR: "$92K",
      changes: { totalClaims: "+13.5%", totalPayments: "+9.2%", gcr: "+2.3%", ncr: "+1.9%", denialRate: "-1.4%", fpr: "+3.8%", ccr: "+0.9%", totalOpenAR: "-4.8%" },
    },
    performanceData: [
      { month: "Jul", GCR: 89.5, NCR: 84.0, DR: 7.8, CCR: 92.5, FPR: 86.5, TotalPayments: 420000 },
      { month: "Aug", GCR: 90.5, NCR: 85.5, DR: 7.0, CCR: 93.2, FPR: 87.8, TotalPayments: 460000 },
      { month: "Sep", GCR: 91.8, NCR: 86.8, DR: 6.5, CCR: 94.0, FPR: 89.0, TotalPayments: 490000 },
      { month: "Oct", GCR: 92.5, NCR: 87.8, DR: 6.0, CCR: 94.8, FPR: 90.0, TotalPayments: 520000 },
      { month: "Nov", GCR: 93.5, NCR: 89.0, DR: 5.5, CCR: 95.5, FPR: 91.0, TotalPayments: 540000 },
      { month: "Dec", GCR: 94.0, NCR: 89.5, DR: 5.2, CCR: 96.0, FPR: 91.5, TotalPayments: 560000 },
      { month: "Jan", GCR: 94.3, NCR: 89.8, DR: 5.0, CCR: 96.3, FPR: 91.8, TotalPayments: 570000 },
      { month: "Feb", GCR: 94.5, NCR: 90.1, DR: 4.8, CCR: 96.5, FPR: 92.0, TotalPayments: 580000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 220, processed: 210, denied: 18 },
      { month: "Aug", submitted: 250, processed: 240, denied: 18 },
      { month: "Sep", submitted: 280, processed: 270, denied: 17 },
      { month: "Oct", submitted: 285, processed: 275, denied: 16 },
      { month: "Nov", submitted: 310, processed: 300, denied: 15 },
      { month: "Dec", submitted: 285, processed: 275, denied: 14 },
      { month: "Jan", submitted: 320, processed: 310, denied: 16 },
      { month: "Feb", submitted: 330, processed: 320, denied: 16 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 30000 },
      { bucket: "31-60 days", amount: 24000 },
      { bucket: "61-90 days", amount: 18000 },
      { bucket: "90+ days", amount: 20000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 22, percentage: 26 },
      { reason: "Invalid Code", count: 20, percentage: 24 },
      { reason: "Missing Info", count: 18, percentage: 21 },
      { reason: "Timely Filing", count: 14, percentage: 17 },
      { reason: "Duplicate", count: 10, percentage: 12 },
    ],
    revenueData: makeRevenue(580000),
    periodComparison: makePeriodComparison(94.5, 90.1, 96.5, 92.0, 4.8),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "gce", name: "GCE", shortName: "GCE",
    kpis: { totalClaims: "1,845", totalPayments: "$460K", gcr: "91.2%", ncr: "86.5%", denialRate: "6.8%", fpr: "88.1%", ccr: "94.2%", totalOpenAR: "$178K",
      changes: { totalClaims: "+8.5%", totalPayments: "+5.2%", gcr: "+1.5%", ncr: "+1.2%", denialRate: "-0.7%", fpr: "+2.1%", ccr: "+0.5%", totalOpenAR: "-2.8%" } },
    performanceData: [
      { month: "Jul", GCR: 86.2, NCR: 80.5, DR: 9.5, CCR: 90.0, FPR: 83.5, TotalPayments: 380000 },
      { month: "Aug", GCR: 87.5, NCR: 81.8, DR: 8.8, CCR: 90.8, FPR: 84.8, TotalPayments: 400000 },
      { month: "Sep", GCR: 88.5, NCR: 83.0, DR: 8.2, CCR: 91.5, FPR: 85.8, TotalPayments: 420000 },
      { month: "Oct", GCR: 89.2, NCR: 84.0, DR: 7.8, CCR: 92.2, FPR: 86.5, TotalPayments: 430000 },
      { month: "Nov", GCR: 90.0, NCR: 85.2, DR: 7.3, CCR: 93.0, FPR: 87.2, TotalPayments: 440000 },
      { month: "Dec", GCR: 90.5, NCR: 85.8, DR: 7.0, CCR: 93.5, FPR: 87.5, TotalPayments: 445000 },
      { month: "Jan", GCR: 90.8, NCR: 86.2, DR: 6.9, CCR: 93.8, FPR: 87.8, TotalPayments: 455000 },
      { month: "Feb", GCR: 91.2, NCR: 86.5, DR: 6.8, CCR: 94.2, FPR: 88.1, TotalPayments: 460000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 200, processed: 185, denied: 22 },
      { month: "Aug", submitted: 215, processed: 200, denied: 21 },
      { month: "Sep", submitted: 225, processed: 210, denied: 20 },
      { month: "Oct", submitted: 235, processed: 220, denied: 19 },
      { month: "Nov", submitted: 245, processed: 230, denied: 18 },
      { month: "Dec", submitted: 230, processed: 215, denied: 17 },
      { month: "Jan", submitted: 255, processed: 240, denied: 19 },
      { month: "Feb", submitted: 260, processed: 245, denied: 19 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 55000 },
      { bucket: "31-60 days", amount: 45000 },
      { bucket: "61-90 days", amount: 38000 },
      { bucket: "90+ days", amount: 40000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 28, percentage: 29 },
      { reason: "Invalid Code", count: 24, percentage: 25 },
      { reason: "Missing Info", count: 20, percentage: 21 },
      { reason: "Timely Filing", count: 15, percentage: 15 },
      { reason: "Duplicate", count: 10, percentage: 10 },
    ],
    revenueData: makeRevenue(460000),
    periodComparison: makePeriodComparison(91.2, 86.5, 94.2, 88.1, 6.8),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "southtexas", name: "South Texas Spine", shortName: "South Texas spine",
    kpis: { totalClaims: "1,620", totalPayments: "$410K", gcr: "93.0%", ncr: "88.2%", denialRate: "5.5%", fpr: "90.8%", ccr: "95.5%", totalOpenAR: "$145K",
      changes: { totalClaims: "+9.2%", totalPayments: "+6.8%", gcr: "+1.9%", ncr: "+1.5%", denialRate: "-1.0%", fpr: "+2.9%", ccr: "+0.6%", totalOpenAR: "-3.2%" } },
    performanceData: [
      { month: "Jul", GCR: 88.0, NCR: 82.2, DR: 8.2, CCR: 91.2, FPR: 85.2, TotalPayments: 340000 },
      { month: "Aug", GCR: 89.2, NCR: 83.5, DR: 7.5, CCR: 92.0, FPR: 86.5, TotalPayments: 355000 },
      { month: "Sep", GCR: 90.2, NCR: 84.8, DR: 7.0, CCR: 92.8, FPR: 87.5, TotalPayments: 370000 },
      { month: "Oct", GCR: 91.0, NCR: 85.8, DR: 6.5, CCR: 93.5, FPR: 88.5, TotalPayments: 380000 },
      { month: "Nov", GCR: 91.8, NCR: 86.8, DR: 6.0, CCR: 94.2, FPR: 89.5, TotalPayments: 390000 },
      { month: "Dec", GCR: 92.2, NCR: 87.2, DR: 5.8, CCR: 94.8, FPR: 90.0, TotalPayments: 395000 },
      { month: "Jan", GCR: 92.8, NCR: 87.8, DR: 5.6, CCR: 95.2, FPR: 90.5, TotalPayments: 405000 },
      { month: "Feb", GCR: 93.0, NCR: 88.2, DR: 5.5, CCR: 95.5, FPR: 90.8, TotalPayments: 410000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 180, processed: 168, denied: 16 },
      { month: "Aug", submitted: 190, processed: 178, denied: 15 },
      { month: "Sep", submitted: 200, processed: 188, denied: 15 },
      { month: "Oct", submitted: 205, processed: 193, denied: 14 },
      { month: "Nov", submitted: 215, processed: 203, denied: 13 },
      { month: "Dec", submitted: 200, processed: 188, denied: 12 },
      { month: "Jan", submitted: 220, processed: 208, denied: 14 },
      { month: "Feb", submitted: 225, processed: 213, denied: 14 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 48000 },
      { bucket: "31-60 days", amount: 38000 },
      { bucket: "61-90 days", amount: 30000 },
      { bucket: "90+ days", amount: 29000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 20, percentage: 27 },
      { reason: "Invalid Code", count: 18, percentage: 24 },
      { reason: "Missing Info", count: 16, percentage: 22 },
      { reason: "Timely Filing", count: 12, percentage: 16 },
      { reason: "Duplicate", count: 8, percentage: 11 },
    ],
    revenueData: makeRevenue(410000),
    periodComparison: makePeriodComparison(93.0, 88.2, 95.5, 90.8, 5.5),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "eca", name: "ECA", shortName: "ECA",
    kpis: { totalClaims: "1,450", totalPayments: "$365K", gcr: "92.8%", ncr: "87.5%", denialRate: "5.9%", fpr: "89.8%", ccr: "95.2%", totalOpenAR: "$132K",
      changes: { totalClaims: "+7.8%", totalPayments: "+5.5%", gcr: "+1.6%", ncr: "+1.3%", denialRate: "-0.8%", fpr: "+2.5%", ccr: "+0.5%", totalOpenAR: "-2.5%" } },
    performanceData: [
      { month: "Jul", GCR: 87.5, NCR: 81.5, DR: 8.8, CCR: 91.0, FPR: 84.5, TotalPayments: 300000 },
      { month: "Aug", GCR: 88.8, NCR: 82.8, DR: 8.0, CCR: 91.8, FPR: 85.8, TotalPayments: 320000 },
      { month: "Sep", GCR: 89.8, NCR: 84.0, DR: 7.5, CCR: 92.5, FPR: 86.8, TotalPayments: 335000 },
      { month: "Oct", GCR: 90.5, NCR: 85.0, DR: 7.0, CCR: 93.2, FPR: 87.8, TotalPayments: 345000 },
      { month: "Nov", GCR: 91.5, NCR: 86.2, DR: 6.5, CCR: 94.0, FPR: 88.8, TotalPayments: 350000 },
      { month: "Dec", GCR: 92.0, NCR: 86.8, DR: 6.2, CCR: 94.5, FPR: 89.2, TotalPayments: 355000 },
      { month: "Jan", GCR: 92.5, NCR: 87.2, DR: 6.0, CCR: 94.8, FPR: 89.5, TotalPayments: 360000 },
      { month: "Feb", GCR: 92.8, NCR: 87.5, DR: 5.9, CCR: 95.2, FPR: 89.8, TotalPayments: 365000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 160, processed: 148, denied: 15 },
      { month: "Aug", submitted: 170, processed: 158, denied: 14 },
      { month: "Sep", submitted: 178, processed: 166, denied: 14 },
      { month: "Oct", submitted: 185, processed: 173, denied: 13 },
      { month: "Nov", submitted: 192, processed: 180, denied: 12 },
      { month: "Dec", submitted: 180, processed: 168, denied: 11 },
      { month: "Jan", submitted: 195, processed: 183, denied: 13 },
      { month: "Feb", submitted: 200, processed: 188, denied: 13 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 42000 },
      { bucket: "31-60 days", amount: 35000 },
      { bucket: "61-90 days", amount: 28000 },
      { bucket: "90+ days", amount: 27000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 18, percentage: 28 },
      { reason: "Invalid Code", count: 15, percentage: 23 },
      { reason: "Missing Info", count: 14, percentage: 22 },
      { reason: "Timely Filing", count: 10, percentage: 16 },
      { reason: "Duplicate", count: 7, percentage: 11 },
    ],
    revenueData: makeRevenue(365000),
    periodComparison: makePeriodComparison(92.8, 87.5, 95.2, 89.8, 5.9),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "piedmont", name: "Piedmont", shortName: "Piedmont",
    kpis: { totalClaims: "1,280", totalPayments: "$320K", gcr: "94.0%", ncr: "89.5%", denialRate: "5.0%", fpr: "91.5%", ccr: "96.0%", totalOpenAR: "$108K",
      changes: { totalClaims: "+12.0%", totalPayments: "+8.5%", gcr: "+2.2%", ncr: "+1.8%", denialRate: "-1.3%", fpr: "+3.5%", ccr: "+0.8%", totalOpenAR: "-4.5%" } },
    performanceData: [
      { month: "Jul", GCR: 89.0, NCR: 83.5, DR: 8.0, CCR: 92.0, FPR: 86.0, TotalPayments: 260000 },
      { month: "Aug", GCR: 90.2, NCR: 84.8, DR: 7.2, CCR: 92.8, FPR: 87.2, TotalPayments: 275000 },
      { month: "Sep", GCR: 91.2, NCR: 86.0, DR: 6.5, CCR: 93.5, FPR: 88.2, TotalPayments: 288000 },
      { month: "Oct", GCR: 92.0, NCR: 87.0, DR: 6.0, CCR: 94.2, FPR: 89.2, TotalPayments: 298000 },
      { month: "Nov", GCR: 93.0, NCR: 88.2, DR: 5.5, CCR: 95.0, FPR: 90.2, TotalPayments: 305000 },
      { month: "Dec", GCR: 93.5, NCR: 88.8, DR: 5.2, CCR: 95.5, FPR: 90.8, TotalPayments: 310000 },
      { month: "Jan", GCR: 93.8, NCR: 89.2, DR: 5.1, CCR: 95.8, FPR: 91.2, TotalPayments: 315000 },
      { month: "Feb", GCR: 94.0, NCR: 89.5, DR: 5.0, CCR: 96.0, FPR: 91.5, TotalPayments: 320000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 140, processed: 130, denied: 12 },
      { month: "Aug", submitted: 150, processed: 140, denied: 11 },
      { month: "Sep", submitted: 158, processed: 148, denied: 11 },
      { month: "Oct", submitted: 165, processed: 155, denied: 10 },
      { month: "Nov", submitted: 170, processed: 160, denied: 10 },
      { month: "Dec", submitted: 160, processed: 150, denied: 9 },
      { month: "Jan", submitted: 175, processed: 165, denied: 10 },
      { month: "Feb", submitted: 180, processed: 170, denied: 10 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 35000 },
      { bucket: "31-60 days", amount: 28000 },
      { bucket: "61-90 days", amount: 22000 },
      { bucket: "90+ days", amount: 23000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 15, percentage: 27 },
      { reason: "Invalid Code", count: 13, percentage: 24 },
      { reason: "Missing Info", count: 12, percentage: 22 },
      { reason: "Timely Filing", count: 9, percentage: 16 },
      { reason: "Duplicate", count: 6, percentage: 11 },
    ],
    revenueData: makeRevenue(320000),
    periodComparison: makePeriodComparison(94.0, 89.5, 96.0, 91.5, 5.0),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "soundhealth", name: "Sound Health", shortName: "Sound Health",
    kpis: { totalClaims: "1,120", totalPayments: "$285K", gcr: "91.8%", ncr: "86.8%", denialRate: "6.5%", fpr: "88.5%", ccr: "94.5%", totalOpenAR: "$125K",
      changes: { totalClaims: "+6.5%", totalPayments: "+4.8%", gcr: "+1.4%", ncr: "+1.1%", denialRate: "-0.6%", fpr: "+1.8%", ccr: "+0.4%", totalOpenAR: "-2.2%" } },
    performanceData: [
      { month: "Jul", GCR: 86.5, NCR: 80.8, DR: 9.2, CCR: 90.2, FPR: 83.8, TotalPayments: 235000 },
      { month: "Aug", GCR: 87.8, NCR: 82.0, DR: 8.5, CCR: 91.0, FPR: 84.8, TotalPayments: 248000 },
      { month: "Sep", GCR: 88.8, NCR: 83.2, DR: 8.0, CCR: 91.8, FPR: 85.8, TotalPayments: 258000 },
      { month: "Oct", GCR: 89.5, NCR: 84.2, DR: 7.5, CCR: 92.5, FPR: 86.8, TotalPayments: 265000 },
      { month: "Nov", GCR: 90.5, NCR: 85.5, DR: 7.0, CCR: 93.2, FPR: 87.5, TotalPayments: 272000 },
      { month: "Dec", GCR: 91.0, NCR: 86.0, DR: 6.8, CCR: 93.8, FPR: 88.0, TotalPayments: 278000 },
      { month: "Jan", GCR: 91.5, NCR: 86.5, DR: 6.6, CCR: 94.2, FPR: 88.2, TotalPayments: 282000 },
      { month: "Feb", GCR: 91.8, NCR: 86.8, DR: 6.5, CCR: 94.5, FPR: 88.5, TotalPayments: 285000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 125, processed: 115, denied: 12 },
      { month: "Aug", submitted: 130, processed: 120, denied: 11 },
      { month: "Sep", submitted: 138, processed: 128, denied: 11 },
      { month: "Oct", submitted: 142, processed: 132, denied: 10 },
      { month: "Nov", submitted: 148, processed: 138, denied: 10 },
      { month: "Dec", submitted: 140, processed: 130, denied: 9 },
      { month: "Jan", submitted: 152, processed: 142, denied: 10 },
      { month: "Feb", submitted: 155, processed: 145, denied: 10 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 40000 },
      { bucket: "31-60 days", amount: 32000 },
      { bucket: "61-90 days", amount: 26000 },
      { bucket: "90+ days", amount: 27000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 14, percentage: 28 },
      { reason: "Invalid Code", count: 12, percentage: 24 },
      { reason: "Missing Info", count: 11, percentage: 22 },
      { reason: "Timely Filing", count: 8, percentage: 16 },
      { reason: "Duplicate", count: 5, percentage: 10 },
    ],
    revenueData: makeRevenue(285000),
    periodComparison: makePeriodComparison(91.8, 86.8, 94.5, 88.5, 6.5),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "wha", name: "WHA", shortName: "WHA",
    kpis: { totalClaims: "980", totalPayments: "$248K", gcr: "93.2%", ncr: "88.0%", denialRate: "5.2%", fpr: "90.5%", ccr: "95.8%", totalOpenAR: "$95K",
      changes: { totalClaims: "+8.8%", totalPayments: "+6.2%", gcr: "+1.8%", ncr: "+1.4%", denialRate: "-0.9%", fpr: "+2.6%", ccr: "+0.6%", totalOpenAR: "-3.0%" } },
    performanceData: [
      { month: "Jul", GCR: 88.2, NCR: 82.5, DR: 8.0, CCR: 91.5, FPR: 85.5, TotalPayments: 205000 },
      { month: "Aug", GCR: 89.5, NCR: 83.8, DR: 7.2, CCR: 92.2, FPR: 86.8, TotalPayments: 215000 },
      { month: "Sep", GCR: 90.5, NCR: 85.0, DR: 6.8, CCR: 93.0, FPR: 87.8, TotalPayments: 225000 },
      { month: "Oct", GCR: 91.2, NCR: 86.0, DR: 6.2, CCR: 93.8, FPR: 88.5, TotalPayments: 232000 },
      { month: "Nov", GCR: 92.0, NCR: 87.0, DR: 5.8, CCR: 94.5, FPR: 89.5, TotalPayments: 238000 },
      { month: "Dec", GCR: 92.5, NCR: 87.5, DR: 5.5, CCR: 95.0, FPR: 90.0, TotalPayments: 242000 },
      { month: "Jan", GCR: 93.0, NCR: 87.8, DR: 5.3, CCR: 95.5, FPR: 90.2, TotalPayments: 245000 },
      { month: "Feb", GCR: 93.2, NCR: 88.0, DR: 5.2, CCR: 95.8, FPR: 90.5, TotalPayments: 248000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 108, processed: 100, denied: 9 },
      { month: "Aug", submitted: 112, processed: 104, denied: 9 },
      { month: "Sep", submitted: 118, processed: 110, denied: 8 },
      { month: "Oct", submitted: 122, processed: 114, denied: 8 },
      { month: "Nov", submitted: 128, processed: 120, denied: 7 },
      { month: "Dec", submitted: 120, processed: 112, denied: 7 },
      { month: "Jan", submitted: 132, processed: 124, denied: 8 },
      { month: "Feb", submitted: 135, processed: 127, denied: 8 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 30000 },
      { bucket: "31-60 days", amount: 25000 },
      { bucket: "61-90 days", amount: 20000 },
      { bucket: "90+ days", amount: 20000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 12, percentage: 27 },
      { reason: "Invalid Code", count: 10, percentage: 23 },
      { reason: "Missing Info", count: 9, percentage: 21 },
      { reason: "Timely Filing", count: 7, percentage: 16 },
      { reason: "Duplicate", count: 6, percentage: 13 },
    ],
    revenueData: makeRevenue(248000),
    periodComparison: makePeriodComparison(93.2, 88.0, 95.8, 90.5, 5.2),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
  {
    id: "entfw", name: "ENTFW", shortName: "ENTFW",
    kpis: { totalClaims: "855", totalPayments: "$215K", gcr: "92.0%", ncr: "87.0%", denialRate: "6.2%", fpr: "89.0%", ccr: "94.8%", totalOpenAR: "$88K",
      changes: { totalClaims: "+7.2%", totalPayments: "+5.0%", gcr: "+1.5%", ncr: "+1.2%", denialRate: "-0.7%", fpr: "+2.0%", ccr: "+0.4%", totalOpenAR: "-2.0%" } },
    performanceData: [
      { month: "Jul", GCR: 87.0, NCR: 81.0, DR: 9.0, CCR: 90.5, FPR: 84.0, TotalPayments: 175000 },
      { month: "Aug", GCR: 88.2, NCR: 82.2, DR: 8.2, CCR: 91.2, FPR: 85.2, TotalPayments: 185000 },
      { month: "Sep", GCR: 89.2, NCR: 83.5, DR: 7.8, CCR: 92.0, FPR: 86.2, TotalPayments: 192000 },
      { month: "Oct", GCR: 90.0, NCR: 84.5, DR: 7.2, CCR: 92.8, FPR: 87.0, TotalPayments: 198000 },
      { month: "Nov", GCR: 90.8, NCR: 85.5, DR: 6.8, CCR: 93.5, FPR: 87.8, TotalPayments: 205000 },
      { month: "Dec", GCR: 91.2, NCR: 86.0, DR: 6.5, CCR: 94.0, FPR: 88.2, TotalPayments: 208000 },
      { month: "Jan", GCR: 91.8, NCR: 86.5, DR: 6.3, CCR: 94.5, FPR: 88.8, TotalPayments: 212000 },
      { month: "Feb", GCR: 92.0, NCR: 87.0, DR: 6.2, CCR: 94.8, FPR: 89.0, TotalPayments: 215000 },
    ],
    claimsVolume: [
      { month: "Jul", submitted: 95, processed: 88, denied: 8 },
      { month: "Aug", submitted: 100, processed: 93, denied: 8 },
      { month: "Sep", submitted: 105, processed: 98, denied: 7 },
      { month: "Oct", submitted: 108, processed: 101, denied: 7 },
      { month: "Nov", submitted: 112, processed: 105, denied: 7 },
      { month: "Dec", submitted: 105, processed: 98, denied: 6 },
      { month: "Jan", submitted: 115, processed: 108, denied: 7 },
      { month: "Feb", submitted: 118, processed: 111, denied: 7 },
    ],
    arAging: [
      { bucket: "0-30 days", amount: 28000 },
      { bucket: "31-60 days", amount: 22000 },
      { bucket: "61-90 days", amount: 18000 },
      { bucket: "90+ days", amount: 20000 },
    ],
    denialReasons: [
      { reason: "Auth Required", count: 10, percentage: 27 },
      { reason: "Invalid Code", count: 9, percentage: 24 },
      { reason: "Missing Info", count: 8, percentage: 22 },
      { reason: "Timely Filing", count: 6, percentage: 16 },
      { reason: "Duplicate", count: 4, percentage: 11 },
    ],
    revenueData: makeRevenue(215000),
    periodComparison: makePeriodComparison(92.0, 87.0, 94.8, 89.0, 6.2),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  },
];

export function getClients(): ClientData[] {
  return clients;
}

export function getClientById(id: string): ClientData | undefined {
  return clients.find((c) => c.id === id);
}

export function getAllClientsAggregated(): ClientData {
  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);

  const months = clients[0].performanceData.map((d) => d.month);
  const performanceData: PerformanceDataPoint[] = months.map((month, i) => ({
    month,
    GCR: +avg(clients.map((c) => c.performanceData[i].GCR)).toFixed(1),
    NCR: +avg(clients.map((c) => c.performanceData[i].NCR)).toFixed(1),
    DR: +avg(clients.map((c) => c.performanceData[i].DR)).toFixed(1),
    CCR: +avg(clients.map((c) => c.performanceData[i].CCR)).toFixed(1),
    FPR: +avg(clients.map((c) => c.performanceData[i].FPR)).toFixed(1),
    TotalPayments: Math.round(sum(clients.map((c) => c.performanceData[i].TotalPayments))),
  }));

  const claimsMonths = clients[0].claimsVolume.map((d) => d.month);
  const claimsVolume: ClaimsVolumePoint[] = claimsMonths.map((month, i) => ({
    month,
    submitted: Math.round(sum(clients.map((c) => c.claimsVolume[i].submitted))),
    processed: Math.round(sum(clients.map((c) => c.claimsVolume[i].processed))),
    denied: Math.round(sum(clients.map((c) => c.claimsVolume[i].denied))),
  }));

  const buckets = clients[0].arAging.map((d) => d.bucket);
  const arAging: ArAgingPoint[] = buckets.map((bucket, i) => ({
    bucket,
    amount: Math.round(sum(clients.map((c) => c.arAging[i].amount))),
  }));

  const reasonNames = clients[0].denialReasons.map((d) => d.reason);
  const denialReasons: DenialReason[] = reasonNames.map((reason, i) => {
    const totalCount = sum(clients.map((c) => c.denialReasons[i].count));
    return { reason, count: totalCount, percentage: Math.round(avg(clients.map((c) => c.denialReasons[i].percentage))) };
  });

  const revenueData: RevenuePoint[] = months.map((month, i) => ({
    month,
    payments: Math.round(sum(clients.map((c) => c.revenueData[i].payments))),
    billed: Math.round(sum(clients.map((c) => c.revenueData[i].billed))),
  }));

  return {
    id: "all",
    name: "All Clients",
    shortName: "All Clients",
    kpis: {
      totalClaims: "12,847", totalPayments: "$2.4M", gcr: "94.2%", ncr: "89.5%",
      denialRate: "5.3%", fpr: "91.2%", ccr: "96.1%", totalOpenAR: "$847K",
      changes: { totalClaims: "+12.5%", totalPayments: "+8.2%", gcr: "+2.1%", ncr: "+1.8%", denialRate: "-1.2%", fpr: "+3.5%", ccr: "+0.8%", totalOpenAR: "-4.2%" },
    },
    performanceData,
    claimsVolume,
    arAging,
    denialReasons,
    revenueData,
    periodComparison: makePeriodComparison(94.2, 89.5, 96.1, 91.2, 5.3),
    automationItems: defaultAutomation,
    clientPerformance: defaultPerformanceTable,
  };
}
