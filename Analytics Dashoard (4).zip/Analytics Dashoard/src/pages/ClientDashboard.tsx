import { useParams, Navigate } from "react-router-dom";
import { DashboardLayout } from "@/components/DashboardLayout";
import { getClientById } from "@/data/clients";

export default function ClientDashboard() {
  const { clientId } = useParams();
  const client = getClientById(clientId || "");

  if (!client) {
    return <Navigate to="/" replace />;
  }

  return <DashboardLayout client={client} />;
}
